
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
      $c1=(isset($_FILES['file'])&&($_FILES['file']['error']==0));
      $c2=(($_FILES['file']['size']<=1000000)&& ($_FILES['file']['type']=='ZIP')&&(pathinfo($FILES['file']['name'])['extension']=='zip') );
      if($c1 && $c2){
        echo"<ul>";
        echo "<li>le ficher a bien été envoyé (Il ne comporte pas d erreur)</li>";
        echo "<li>le ficher ne depasse pas 1MO</li>";
        echo "<li>le ficher est de type ZIP et porte l 'extension .zip</li>";
        echo"<ul>";
        move_uploaded_file($_FILES['file']['tmp_name'],'telechargements/'.$_FILES['file']['name']);
        echo"<h2>ENVOIE EFFECTUE</h2>";
      }

    ?>

</body>
</html>
